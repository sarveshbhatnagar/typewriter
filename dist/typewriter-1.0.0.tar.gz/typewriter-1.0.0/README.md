# Why CodeSnip
Its completely free, open source package which helps you print to the console in beautiful ways.

## Usage

import typewriter

typewriter.write('Hello, World')
